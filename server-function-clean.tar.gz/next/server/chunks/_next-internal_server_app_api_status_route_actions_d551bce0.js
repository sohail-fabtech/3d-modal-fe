module.exports=[88142,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_status_route_actions_d551bce0.js.map