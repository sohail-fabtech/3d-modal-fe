module.exports=[19320,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_editor_%5Bid%5D_route_actions_24e53a7a.js.map