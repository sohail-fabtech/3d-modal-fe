module.exports=[55727,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_editor_route_actions_27da880f.js.map