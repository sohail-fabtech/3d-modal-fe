module.exports=[3879,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_download_route_actions_1a344694.js.map