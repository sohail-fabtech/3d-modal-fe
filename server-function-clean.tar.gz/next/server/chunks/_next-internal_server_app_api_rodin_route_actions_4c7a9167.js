module.exports=[99517,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_rodin_route_actions_4c7a9167.js.map