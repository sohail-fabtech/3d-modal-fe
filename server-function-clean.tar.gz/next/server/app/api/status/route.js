var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/status/route.js")
R.c("server/chunks/[root-of-the-server]__08a34785._.js")
R.c("server/chunks/[root-of-the-server]__b18ae199._.js")
R.c("server/chunks/_next-internal_server_app_api_status_route_actions_d551bce0.js")
R.m(47570)
module.exports=R.m(47570).exports
