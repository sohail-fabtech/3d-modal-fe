var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/route.js")
R.c("server/chunks/[root-of-the-server]__53705ed0._.js")
R.c("server/chunks/[root-of-the-server]__b18ae199._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_route_actions_693293fe.js")
R.m(58651)
module.exports=R.m(58651).exports
