var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/proxy-download/route.js")
R.c("server/chunks/[root-of-the-server]__231266b6._.js")
R.c("server/chunks/[root-of-the-server]__b18ae199._.js")
R.c("server/chunks/_next-internal_server_app_api_proxy-download_route_actions_2d8a723d.js")
R.m(5740)
module.exports=R.m(5740).exports
