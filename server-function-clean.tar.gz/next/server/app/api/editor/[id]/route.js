var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/editor/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__50575e11._.js")
R.c("server/chunks/[root-of-the-server]__b18ae199._.js")
R.c("server/chunks/_next-internal_server_app_api_editor_[id]_route_actions_24e53a7a.js")
R.m(93126)
module.exports=R.m(93126).exports
