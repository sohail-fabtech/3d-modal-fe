var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/editor/route.js")
R.c("server/chunks/[root-of-the-server]__19957914._.js")
R.c("server/chunks/[root-of-the-server]__b18ae199._.js")
R.c("server/chunks/_next-internal_server_app_api_editor_route_actions_27da880f.js")
R.m(1108)
module.exports=R.m(1108).exports
