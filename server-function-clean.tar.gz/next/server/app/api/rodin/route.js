var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/rodin/route.js")
R.c("server/chunks/[root-of-the-server]__dd9b8a57._.js")
R.c("server/chunks/[root-of-the-server]__b18ae199._.js")
R.c("server/chunks/_next-internal_server_app_api_rodin_route_actions_4c7a9167.js")
R.m(33549)
module.exports=R.m(33549).exports
