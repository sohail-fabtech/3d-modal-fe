var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/download/route.js")
R.c("server/chunks/[root-of-the-server]__2c74f878._.js")
R.c("server/chunks/[root-of-the-server]__b18ae199._.js")
R.c("server/chunks/_next-internal_server_app_api_download_route_actions_1a344694.js")
R.m(24866)
module.exports=R.m(24866).exports
