var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/health/route.js")
R.c("server/chunks/[root-of-the-server]__fd57d98d._.js")
R.c("server/chunks/[root-of-the-server]__b18ae199._.js")
R.c("server/chunks/_next-internal_server_app_api_health_route_actions_da3433c4.js")
R.m(4315)
module.exports=R.m(4315).exports
